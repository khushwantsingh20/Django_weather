# weather-django

we will learn how to create a Weather app that uses Django as backend. Django provides a Python Web framework based web framework that allows rapid development and clean, pragmatic design.

learn how to make at <a href="https://www.geeksforgeeks.org/weather-app-using-django-python/" target="_blank"> GeeksforGeeks </a>

![screen](screen.png)
